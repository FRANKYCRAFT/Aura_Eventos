@echo off
REM ─────────────────────────────────────────────────────────────
REM AURA EVENTOS API — Ejecución en Windows
REM Si tu MySQL no es root/root, define antes:
REM   set AURA_DB_USER=aura_app
REM   set AURA_DB_PASS=mi_contrasena
REM ─────────────────────────────────────────────────────────────
cd /d "%~dp0"
java -cp "out;lib/*" mx.aura.eventos.Main
