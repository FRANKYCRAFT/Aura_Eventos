#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# AURA EVENTOS API — Compilación (Java puro, sin Maven)
# Requiere: JDK 17+ y el driver de MySQL en lib/
# ─────────────────────────────────────────────────────────────────
set -e
cd "$(dirname "$0")"

if [ ! -f lib/*.jar ] 2>/dev/null && ! ls lib/*.jar > /dev/null 2>&1; then
  echo "[AVISO] No hay ningún .jar en lib/."
  echo "        Descarga el driver de MySQL (mysql-connector-j-9.x.x.jar)"
  echo "        desde https://dev.mysql.com/downloads/connector/j/"
  echo "        (elige 'Platform Independent') y copia el .jar a lib/"
  echo "        La compilación continúa (el driver solo se necesita al ejecutar)."
fi

echo "Compilando..."
find src -name "*.java" > /tmp/aura-sources.txt
javac -encoding UTF-8 -d out @/tmp/aura-sources.txt
echo "Compilación exitosa. Clases en ./out"
echo "Para ejecutar: ./ejecutar.sh"
