# Aura Eventos — API (Java puro + POO, sin frameworks)

API RESTful construida **exclusivamente con Java estándar del JDK**:
`com.sun.net.httpserver` para el servidor HTTP, `java.sql` (JDBC) para
la base de datos, `javax.crypto` (PBKDF2) para las contraseñas y una
librería JSON propia. **Cero frameworks** — sin Spring, sin Hibernate,
sin Jackson. La única pieza externa es el driver JDBC de MySQL (el
"cable" obligatorio entre Java y la base de datos).

## Programación Orientada a Objetos aplicada

| Pilar | Dónde se ve |
|---|---|
| **Encapsulamiento** | Todos los modelos (`model/`) tienen atributos privados con getters/setters; el hash de contraseña jamás sale en `toMap()` |
| **Abstracción** | Cada dominio define una interfaz (`AuthService`, `ArticuloService`...) y los handlers dependen del contrato, no de la clase concreta |
| **Herencia** | Todos los handlers HTTP extienden `BaseHandler`; las excepciones de dominio extienden `RuntimeException` |
| **Polimorfismo** | `BaseHandler.handle()` es un método plantilla: la lógica común (CORS, errores, JSON) vive en la base y cada subclase sobreescribe `process()` |

## Estructura

```
api-puro/
├── compilar.sh / compilar.bat     ← compila con javac (sin Maven)
├── ejecutar.sh / ejecutar.bat     ← arranca el servidor
├── lib/                           ← aquí va mysql-connector-j (ver lib/LEEME.txt)
└── src/main/java/mx/aura/eventos/
    ├── Main.java                  ← arranque: HttpServer + registro de rutas
    ├── db/Database.java           ← conexión JDBC (config por variables de entorno)
    ├── json/Json.java             ← escritura y parseo JSON hecho a mano
    ├── security/PasswordHasher.java ← PBKDF2-HMAC-SHA256 (javax.crypto)
    ├── model/                     ← Usuario · Categoria · Articulo · Solicitud · SolicitudArticulo · PasswordReset
    ├── dao/                       ← acceso a datos con PreparedStatement (JDBC puro)
    ├── service/                   ← interfaz + implementación por dominio (reglas de negocio)
    ├── http/                      ← BaseHandler + 5 handlers (uno por recurso)
    └── exception/                 ← NegocioException (400) · RecursoNoEncontradoException (404)
```

## Cómo correrlo

```bash
# 0. Requisitos: JDK 17+, MySQL 8 con database.sql ya cargado,
#    y mysql-connector-j-9.x.x.jar dentro de lib/ (ver lib/LEEME.txt)

# 1. Compilar
./compilar.sh          # Windows: compilar.bat

# 2. Ejecutar (si tu MySQL no es root/root, exporta AURA_DB_USER / AURA_DB_PASS)
./ejecutar.sh          # Windows: ejecutar.bat
```

Prueba rápida:

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@aura.mx","password":"admin123"}'
```

## Variables de entorno

| Variable | Default | Uso |
|---|---|---|
| `AURA_PORT` | 8080 | Puerto del servidor |
| `AURA_DB_URL` | jdbc:mysql://localhost:3306/aura_eventos?... | Cadena JDBC |
| `AURA_DB_USER` | root | Usuario de MySQL |
| `AURA_DB_PASS` | root | Contraseña de MySQL |
| `AURA_CORS_ORIGINS` | * | Orígenes CORS (en producción con nginx no se usa) |

## Endpoints

| Método | Ruta | Descripción |
|---|---|---|
| POST | `/api/auth/login` | Iniciar sesión |
| POST | `/api/auth/registro` | Registrar cliente |
| POST | `/api/auth/forgot-password` | Generar código de recuperación |
| POST | `/api/auth/verify-reset-code` | Validar código |
| POST | `/api/auth/reset-password` | Cambiar contraseña con código |
| GET | `/api/usuarios/clientes` | Directorio de clientes (admin) |
| PUT | `/api/usuarios/{id}` | Actualizar perfil |
| POST | `/api/usuarios/{id}/change-password` | Cambiar contraseña propia |
| POST | `/api/usuarios/{id}/reset-password` | Contraseña temporal (admin) |
| GET | `/api/articulos` | Catálogo (solo activos) |
| GET | `/api/articulos/admin` | Inventario completo |
| GET | `/api/articulos/{id}` | Detalle |
| GET | `/api/articulos/{id}/disponibilidad` | Stock para un rango de fechas |
| POST | `/api/articulos?categoriaId=` | Alta |
| PUT | `/api/articulos/{id}?categoriaId=` | Edición |
| PATCH | `/api/articulos/{id}/habilitar` · `/deshabilitar` | Alta/baja lógica |
| DELETE | `/api/articulos/{id}` | Borrado (si no tiene historial) |
| GET / POST | `/api/categorias` | Listar / crear |
| DELETE | `/api/categorias/{id}` | Eliminar (si no está en uso) |
| GET | `/api/solicitudes` | Agenda completa (admin) |
| GET | `/api/solicitudes/cliente/{id}` | Historial del cliente |
| GET | `/api/solicitudes/{id}` | Detalle |
| POST | `/api/solicitudes` | Crear (valida anti-overbooking, IVA 16 %) |
| PATCH | `/api/solicitudes/{id}/aprobar` | Aprobar + flete |
| PATCH | `/api/solicitudes/{id}/rechazar` | Rechazar + motivo |

Errores siempre en JSON: `{"ok": false, "error": "mensaje"}` con
400 (regla de negocio), 404 (no existe) o 500 (interno, sin stacktrace).
