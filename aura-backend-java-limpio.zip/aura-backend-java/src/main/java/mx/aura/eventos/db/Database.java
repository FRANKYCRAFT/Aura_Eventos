package mx.aura.eventos.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class Database {

    private static final String URL = env("AURA_DB_URL",
            "jdbc:mysql://localhost:3306/aura_eventos"
            + "?useSSL=false&serverTimezone=America/Mexico_City&allowPublicKeyRetrieval=true");
    private static final String USER = env("AURA_DB_USER", "root");
    private static final String PASS = env("AURA_DB_PASS", "root");

    private Database() { }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    private static String env(String key, String def) {
        String v = System.getenv(key);
        return (v == null || v.isBlank()) ? def : v;
    }
}
