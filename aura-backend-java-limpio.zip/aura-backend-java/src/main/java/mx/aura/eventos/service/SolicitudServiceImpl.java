package mx.aura.eventos.service;

import mx.aura.eventos.dao.ArticuloDao;
import mx.aura.eventos.dao.SolicitudDao;
import mx.aura.eventos.dao.UsuarioDao;
import mx.aura.eventos.db.Database;
import mx.aura.eventos.exception.NegocioException;
import mx.aura.eventos.exception.RecursoNoEncontradoException;
import mx.aura.eventos.model.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Year;
import java.util.List;
import java.util.Map;

public class SolicitudServiceImpl implements SolicitudService {

    private static final BigDecimal TASA_IVA = new BigDecimal("0.16");

    private final SolicitudDao solicitudDao = new SolicitudDao();
    private final ArticuloDao articuloDao = new ArticuloDao();
    private final UsuarioDao usuarioDao = new UsuarioDao();
    private final ArticuloServiceImpl articuloService = new ArticuloServiceImpl();
    private final SecureRandom random = new SecureRandom();

    @Override
    public List<Solicitud> listarTodas() {
        try (Connection con = Database.getConnection()) {
            return solicitudDao.todas(con);
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al listar solicitudes.", e);
        }
    }

    @Override
    public List<Solicitud> listarPorCliente(String clienteId) {
        try (Connection con = Database.getConnection()) {
            return solicitudDao.porCliente(con, clienteId);
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al listar solicitudes del cliente.", e);
        }
    }

    @Override
    public Solicitud porId(String id) {
        try (Connection con = Database.getConnection()) {
            return solicitudDao.porId(con, id)
                    .orElseThrow(() -> new RecursoNoEncontradoException("Solicitud no encontrada."));
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al consultar la solicitud.", e);
        }
    }

    @Override
    public Solicitud crear(String clienteId, LocalDate fecha, LocalDate fechaFin,
                           String direccion, String notas, List<Map<String, Object>> renglones) {
        if (fecha == null)
            throw new NegocioException("La fecha del evento es requerida.");
        if (direccion == null || direccion.isBlank())
            throw new NegocioException("La dirección del evento es requerida.");
        if (renglones == null || renglones.isEmpty())
            throw new NegocioException("La solicitud debe incluir al menos un artículo.");

        LocalDate fin = (fechaFin != null) ? fechaFin : fecha;
        if (fin.isBefore(fecha))
            throw new NegocioException("La fecha de recogida no puede ser anterior a la de entrega.");

        try (Connection con = Database.getConnection()) {
            con.setAutoCommit(false);
            try {
                Usuario cliente = usuarioDao.porId(con, clienteId)
                        .orElseThrow(() -> new RecursoNoEncontradoException("Cliente no encontrado."));

                Solicitud s = new Solicitud();
                s.setId(generarFolio(con));
                s.setCliente(cliente);
                s.setFechaEvento(fecha);
                s.setFechaFin(fin);
                s.setDireccion(direccion);
                s.setNotas(notas);
                s.setEstado(Solicitud.Estado.pendiente);

                BigDecimal subtotal = BigDecimal.ZERO;
                for (Map<String, Object> r : renglones) {
                    String artId = String.valueOf(r.get("artId"));
                    int cantidad = r.get("cantidad") instanceof Number n ? n.intValue() : 1;
                    if (cantidad < 1)
                        throw new NegocioException("La cantidad mínima es 1.");

                    Articulo a = articuloDao.porId(con, artId)
                            .orElseThrow(() -> new RecursoNoEncontradoException("Artículo no encontrado."));

                    if (!articuloService.disponibleParaFecha(con, artId, fecha, fin, cantidad))
                        throw new NegocioException("\"" + a.getNombre()
                            + "\" no está disponible para la fecha seleccionada. Por favor elige otra fecha.");

                    SolicitudArticulo renglon =
                            new SolicitudArticulo(a, cantidad, a.getPrecio());
                    s.agregarArticulo(renglon);
                    subtotal = subtotal.add(renglon.importe());
                }

                BigDecimal iva = subtotal.multiply(TASA_IVA).setScale(2, RoundingMode.HALF_UP);
                s.setSubtotal(subtotal);
                s.setIva(iva);
                s.setFlete(null);
                s.setTotal(subtotal.add(iva));

                solicitudDao.insertarCabecera(con, s);
                for (SolicitudArticulo r : s.getArticulos())
                    solicitudDao.insertarRenglon(con, s.getId(), r);

                con.commit();
                return s;
            } catch (Exception e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al crear la solicitud.", e);
        }
    }

    @Override
    public Solicitud aprobar(String id, BigDecimal flete) {
        if (flete == null || flete.signum() < 0)
            throw new NegocioException("Ingresa el costo de flete antes de aprobar.");

        try (Connection con = Database.getConnection()) {
            Solicitud s = solicitudDao.porId(con, id)
                    .orElseThrow(() -> new RecursoNoEncontradoException("Solicitud no encontrada."));
            if (s.getEstado() != Solicitud.Estado.pendiente)
                throw new NegocioException("Solo se pueden aprobar solicitudes pendientes.");

            s.setEstado(Solicitud.Estado.aprobado);
            s.setFlete(flete);
            s.setTotal(s.getSubtotal().add(s.getIva()).add(flete));
            solicitudDao.aprobar(con, s);
            return solicitudDao.porId(con, id).orElse(s);
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al aprobar.", e);
        }
    }

    @Override
    public Solicitud rechazar(String id, String motivo) {
        try (Connection con = Database.getConnection()) {
            Solicitud s = solicitudDao.porId(con, id)
                    .orElseThrow(() -> new RecursoNoEncontradoException("Solicitud no encontrada."));
            if (s.getEstado() != Solicitud.Estado.pendiente)
                throw new NegocioException("Solo se pueden rechazar solicitudes pendientes.");

            solicitudDao.rechazar(con, id, motivo == null ? "" : motivo);
            return solicitudDao.porId(con, id).orElse(s);
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al rechazar.", e);
        }
    }

    private String generarFolio(Connection con) throws SQLException {
        String folio;
        do {
            folio = "AUR-" + Year.now().getValue() + "-"
                    + String.format("%04d", 1000 + random.nextInt(9000));
        } while (solicitudDao.existeFolio(con, folio));
        return folio;
    }
}
