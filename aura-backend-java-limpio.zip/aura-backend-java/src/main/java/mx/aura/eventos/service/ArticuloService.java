package mx.aura.eventos.service;

import mx.aura.eventos.model.Articulo;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface ArticuloService {

    List<Articulo> listar(boolean soloActivos);

    Articulo porId(String id);

    Articulo crear(Map<String, Object> datos, int categoriaId);

    Articulo actualizar(String id, Map<String, Object> datos, Integer categoriaId);

    void habilitar(String id);

    void deshabilitar(String id);

    void eliminar(String id);

    boolean disponibleParaFecha(String articuloId, LocalDate fecha, LocalDate fechaFin, int cantidad);
}
