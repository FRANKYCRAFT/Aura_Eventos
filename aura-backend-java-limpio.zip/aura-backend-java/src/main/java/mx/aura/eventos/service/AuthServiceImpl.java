package mx.aura.eventos.service;

import mx.aura.eventos.dao.PasswordResetDao;
import mx.aura.eventos.dao.UsuarioDao;
import mx.aura.eventos.db.Database;
import mx.aura.eventos.exception.NegocioException;
import mx.aura.eventos.exception.RecursoNoEncontradoException;
import mx.aura.eventos.model.PasswordReset;
import mx.aura.eventos.model.Usuario;
import mx.aura.eventos.security.PasswordHasher;

import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class AuthServiceImpl implements AuthService {

    private static final int MINUTOS_VIGENCIA = 10;
    private static final String ALFABETO_TEMPORAL =
            "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";

    private final UsuarioDao usuarioDao = new UsuarioDao();
    private final PasswordResetDao resetDao = new PasswordResetDao();
    private final SecureRandom random = new SecureRandom();

    @Override
    public Usuario login(String email, String password) {
        try (Connection con = Database.getConnection()) {
            Usuario u = usuarioDao.porEmail(con, email)
                    .orElseThrow(() -> new NegocioException("Correo o contraseña incorrectos."));
            if (!PasswordHasher.verify(password, u.getPasswordHash()))
                throw new NegocioException("Correo o contraseña incorrectos.");
            return u;
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos en login.", e);
        }
    }

    @Override
    public Usuario registrar(String nombre, String apellidos, String email,
                             String password, String telefono) {
        if (nombre == null || nombre.isBlank())
            throw new NegocioException("El nombre es requerido.");
        if (email == null || !email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))
            throw new NegocioException("El correo no tiene un formato válido.");
        if (password == null || password.length() < 6)
            throw new NegocioException("La contraseña debe tener al menos 6 caracteres.");

        try (Connection con = Database.getConnection()) {
            if (usuarioDao.existeEmail(con, email))
                throw new NegocioException("Este correo ya está registrado.");

            Usuario u = new Usuario();
            u.setId("u" + System.currentTimeMillis());
            u.setNombre(nombre.trim());
            u.setApellidos(apellidos != null ? apellidos.trim() : null);
            u.setEmail(email.trim().toLowerCase());
            u.setPasswordHash(PasswordHasher.hash(password));
            u.setRol(Usuario.Rol.cliente);
            u.setTelefono(telefono);
            u.setAvatar(iniciales(nombre, apellidos));
            usuarioDao.insertar(con, u);
            return u;
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos en registro.", e);
        }
    }

    @Override
    public String solicitarRecuperacion(String email) {
        try (Connection con = Database.getConnection()) {
            Usuario u = usuarioDao.porEmail(con, email)
                    .orElseThrow(() -> new RecursoNoEncontradoException(
                            "No existe una cuenta registrada con ese correo."));

            String codigo = String.format("%06d", random.nextInt(1_000_000));
            resetDao.insertar(con, new PasswordReset(
                    u.getId(), codigo, LocalDateTime.now().plusMinutes(MINUTOS_VIGENCIA)));

            return codigo;
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al generar el código.", e);
        }
    }

    @Override
    public void verificarCodigo(String email, String codigo) {
        try (Connection con = Database.getConnection()) {
            validar(con, email, codigo);
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al verificar el código.", e);
        }
    }

    @Override
    public void restablecerPassword(String email, String codigo, String nuevaPassword) {
        if (nuevaPassword == null || nuevaPassword.length() < 6)
            throw new NegocioException("La contraseña debe tener al menos 6 caracteres.");

        try (Connection con = Database.getConnection()) {
            con.setAutoCommit(false);
            try {
                PasswordReset pr = validar(con, email, codigo);
                Usuario u = usuarioDao.porEmail(con, email).orElseThrow();
                usuarioDao.actualizarPassword(con, u.getId(), PasswordHasher.hash(nuevaPassword));
                resetDao.marcarUsado(con, pr.getId());
                con.commit();
            } catch (Exception e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al restablecer la contraseña.", e);
        }
    }

    @Override
    public String resetPorAdmin(String usuarioId) {
        try (Connection con = Database.getConnection()) {
            Usuario u = usuarioDao.porId(con, usuarioId)
                    .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado."));

            StringBuilder temp = new StringBuilder("Aura-");
            for (int i = 0; i < 6; i++)
                temp.append(ALFABETO_TEMPORAL.charAt(random.nextInt(ALFABETO_TEMPORAL.length())));

            usuarioDao.actualizarPassword(con, u.getId(), PasswordHasher.hash(temp.toString()));
            return temp.toString();
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos en el reset del administrador.", e);
        }
    }

    private PasswordReset validar(Connection con, String email, String codigo) throws SQLException {
        Usuario u = usuarioDao.porEmail(con, email)
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado."));
        PasswordReset pr = resetDao.ultimo(con, u.getId(), codigo == null ? "" : codigo.trim())
                .orElseThrow(() -> new NegocioException("El código ingresado no es válido."));
        if (pr.isUsado())
            throw new NegocioException("Este código ya fue utilizado. Solicita uno nuevo.");
        if (!pr.esValido())
            throw new NegocioException("El código expiró. Solicita uno nuevo.");
        return pr;
    }

    private String iniciales(String nombre, String apellidos) {
        String n = (nombre != null && !nombre.isBlank()) ? nombre.substring(0, 1) : "";
        String a = (apellidos != null && !apellidos.isBlank()) ? apellidos.substring(0, 1) : "";
        return (n + a).toUpperCase();
    }
}
