package mx.aura.eventos.service;

import mx.aura.eventos.model.Categoria;
import java.util.List;

public interface CategoriaService {

    List<Categoria> listar();

    Categoria crear(String nombre);

    void eliminar(int id);
}
