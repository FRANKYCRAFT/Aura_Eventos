package mx.aura.eventos;

import com.sun.net.httpserver.HttpServer;
import mx.aura.eventos.db.Database;
import mx.aura.eventos.http.*;
import mx.aura.eventos.service.*;

import java.net.InetSocketAddress;
import java.sql.Connection;
import java.util.concurrent.Executors;

public final class Main {

    public static void main(String[] args) throws Exception {
        int puerto = Integer.parseInt(System.getenv().getOrDefault("AURA_PORT", "8080"));

        try (Connection con = Database.getConnection()) {
            System.out.println("[OK] Conexión a la base de datos establecida.");
        } catch (Exception e) {
            System.err.println("[ERROR] No se pudo conectar a la base de datos: " + e.getMessage());
            System.err.println("        Verifica que MySQL esté corriendo, que ejecutaste database.sql");
            System.err.println("        y que AURA_DB_URL / AURA_DB_USER / AURA_DB_PASS sean correctos.");
            System.exit(1);
        }

        AuthService      authService      = new AuthServiceImpl();
        UsuarioService   usuarioService   = new UsuarioServiceImpl();
        ArticuloService  articuloService  = new ArticuloServiceImpl();
        CategoriaService categoriaService = new CategoriaServiceImpl();
        SolicitudService solicitudService = new SolicitudServiceImpl();

        HttpServer server = HttpServer.create(new InetSocketAddress(puerto), 0);
        server.createContext("/api/auth",        new AuthHandler(authService));
        server.createContext("/api/usuarios",    new UsuarioHandler(usuarioService, authService));
        server.createContext("/api/articulos",   new ArticuloHandler(articuloService));
        server.createContext("/api/categorias",  new CategoriaHandler(categoriaService));
        server.createContext("/api/solicitudes", new SolicitudHandler(solicitudService));

        server.setExecutor(Executors.newFixedThreadPool(10));
        server.start();

        System.out.println("═══════════════════════════════════════════════════");
        System.out.println("  AURA EVENTOS API — Java puro (sin frameworks)");
        System.out.println("  Escuchando en   → http://localhost:" + puerto);
        System.out.println("  Endpoints base  → /api/auth · /api/usuarios ·");
        System.out.println("                    /api/articulos · /api/categorias ·");
        System.out.println("                    /api/solicitudes");
        System.out.println("  Detener con Ctrl+C");
        System.out.println("═══════════════════════════════════════════════════");
    }
}
