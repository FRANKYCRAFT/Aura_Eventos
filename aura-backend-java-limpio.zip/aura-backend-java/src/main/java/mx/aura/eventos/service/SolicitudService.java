package mx.aura.eventos.service;

import mx.aura.eventos.model.Solicitud;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface SolicitudService {

    List<Solicitud> listarTodas();

    List<Solicitud> listarPorCliente(String clienteId);

    Solicitud porId(String id);

    Solicitud crear(String clienteId, LocalDate fecha, LocalDate fechaFin,
                    String direccion, String notas, List<Map<String, Object>> renglones);

    Solicitud aprobar(String id, BigDecimal flete);

    Solicitud rechazar(String id, String motivo);
}
