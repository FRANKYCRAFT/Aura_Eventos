package mx.aura.eventos.security;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

public final class PasswordHasher {

    private static final String ALGORITMO   = "PBKDF2WithHmacSHA256";
    private static final int    ITERACIONES = 120_000;
    private static final int    LARGO_SALT  = 16;
    private static final int    LARGO_HASH  = 256;

    private PasswordHasher() { }

    public static String hash(String passwordPlano) {
        byte[] salt = new byte[LARGO_SALT];
        new SecureRandom().nextBytes(salt);
        byte[] hash = pbkdf2(passwordPlano.toCharArray(), salt, ITERACIONES);
        return ITERACIONES + ":" + b64(salt) + ":" + b64(hash);
    }

    public static boolean verify(String passwordPlano, String hashAlmacenado) {
        if (passwordPlano == null || hashAlmacenado == null) return false;
        String[] partes = hashAlmacenado.split(":");
        if (partes.length != 3) return false;

        int iteraciones = Integer.parseInt(partes[0]);
        byte[] salt          = Base64.getDecoder().decode(partes[1]);
        byte[] hashEsperado  = Base64.getDecoder().decode(partes[2]);

        byte[] hashCalculado = pbkdf2(passwordPlano.toCharArray(), salt, iteraciones);
        return constantTimeEquals(hashEsperado, hashCalculado);
    }

    private static byte[] pbkdf2(char[] password, byte[] salt, int iteraciones) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password, salt, iteraciones, LARGO_HASH);
            SecretKeyFactory skf = SecretKeyFactory.getInstance(ALGORITMO);
            return skf.generateSecret(spec).getEncoded();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException("Error al calcular el hash de la contraseña.", e);
        }
    }

    private static boolean constantTimeEquals(byte[] a, byte[] b) {
        if (a.length != b.length) return false;
        int diff = 0;
        for (int i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
        return diff == 0;
    }

    private static String b64(byte[] data) {
        return Base64.getEncoder().encodeToString(data);
    }
}
