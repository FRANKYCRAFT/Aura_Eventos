package mx.aura.eventos.service;

import mx.aura.eventos.dao.ArticuloDao;
import mx.aura.eventos.dao.CategoriaDao;
import mx.aura.eventos.dao.SolicitudDao;
import mx.aura.eventos.db.Database;
import mx.aura.eventos.exception.NegocioException;
import mx.aura.eventos.exception.RecursoNoEncontradoException;
import mx.aura.eventos.model.Articulo;
import mx.aura.eventos.model.Categoria;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class ArticuloServiceImpl implements ArticuloService {

    private static final int UMBRAL_STOCK_BAJO = 3;

    private final ArticuloDao articuloDao = new ArticuloDao();
    private final CategoriaDao categoriaDao = new CategoriaDao();
    private final SolicitudDao solicitudDao = new SolicitudDao();

    @Override
    public List<Articulo> listar(boolean soloActivos) {
        try (Connection con = Database.getConnection()) {
            List<Articulo> lista = articuloDao.todos(con, soloActivos);
            for (Articulo a : lista) calcularDerivados(con, a);
            return lista;
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al listar artículos.", e);
        }
    }

    @Override
    public Articulo porId(String id) {
        try (Connection con = Database.getConnection()) {
            Articulo a = articuloDao.porId(con, id)
                    .orElseThrow(() -> new RecursoNoEncontradoException("Artículo no encontrado."));
            calcularDerivados(con, a);
            return a;
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al consultar el artículo.", e);
        }
    }

    @Override
    public Articulo crear(Map<String, Object> datos, int categoriaId) {
        try (Connection con = Database.getConnection()) {
            String sku = str(datos, "sku");
            if (sku == null || sku.isBlank())
                throw new NegocioException("El SKU es requerido.");
            if (articuloDao.existeSku(con, sku))
                throw new NegocioException("Ya existe un artículo con ese SKU.");

            Categoria cat = categoriaDao.porId(con, categoriaId)
                    .orElseThrow(() -> new RecursoNoEncontradoException("Categoría no encontrada."));

            Articulo a = new Articulo();
            a.setId("art" + System.currentTimeMillis());
            a.setCategoria(cat);
            a.setEstado(Articulo.Estado.activo);
            aplicarDatos(a, datos);
            articuloDao.insertar(con, a);
            calcularDerivados(con, a);
            return a;
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al crear el artículo.", e);
        }
    }

    @Override
    public Articulo actualizar(String id, Map<String, Object> datos, Integer categoriaId) {
        try (Connection con = Database.getConnection()) {
            Articulo a = articuloDao.porId(con, id)
                    .orElseThrow(() -> new RecursoNoEncontradoException("Artículo no encontrado."));
            if (categoriaId != null) {
                Categoria cat = categoriaDao.porId(con, categoriaId)
                        .orElseThrow(() -> new RecursoNoEncontradoException("Categoría no encontrada."));
                a.setCategoria(cat);
            }
            aplicarDatos(a, datos);
            articuloDao.actualizar(con, a);
            calcularDerivados(con, a);
            return a;
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al actualizar el artículo.", e);
        }
    }

    @Override
    public void habilitar(String id) { cambiarEstado(id, Articulo.Estado.activo); }

    @Override
    public void deshabilitar(String id) { cambiarEstado(id, Articulo.Estado.deshabilitado); }

    @Override
    public void eliminar(String id) {
        try (Connection con = Database.getConnection()) {
            articuloDao.porId(con, id)
                    .orElseThrow(() -> new RecursoNoEncontradoException("Artículo no encontrado."));
            if (articuloDao.tieneHistorial(con, id))
                throw new NegocioException(
                    "No se puede eliminar: el artículo aparece en solicitudes históricas. Deshabilítalo en su lugar.");
            articuloDao.eliminar(con, id);
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al eliminar el artículo.", e);
        }
    }

    @Override
    public boolean disponibleParaFecha(String articuloId, LocalDate fecha,
                                       LocalDate fechaFin, int cantidad) {
        try (Connection con = Database.getConnection()) {
            return disponibleParaFecha(con, articuloId, fecha, fechaFin, cantidad);
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al validar disponibilidad.", e);
        }
    }

    boolean disponibleParaFecha(Connection con, String articuloId, LocalDate fecha,
                                LocalDate fechaFin, int cantidad) throws SQLException {
        Articulo a = articuloDao.porId(con, articuloId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Artículo no encontrado."));
        if (a.getEstado() != Articulo.Estado.activo) return false;

        LocalDate fin = (fechaFin != null) ? fechaFin : fecha;
        int ocupadas = solicitudDao.unidadesOcupadas(con, articuloId, fecha, fin);
        return (a.getStockTotal() - ocupadas) >= cantidad;
    }

    private void cambiarEstado(String id, Articulo.Estado estado) {
        try (Connection con = Database.getConnection()) {
            articuloDao.porId(con, id)
                    .orElseThrow(() -> new RecursoNoEncontradoException("Artículo no encontrado."));
            articuloDao.cambiarEstado(con, id, estado);
        } catch (SQLException e) {
            throw new RuntimeException("Error de base de datos al cambiar el estado.", e);
        }
    }

    private void aplicarDatos(Articulo a, Map<String, Object> d) {
        if (d.containsKey("sku") && a.getSku() == null) a.setSku(str(d, "sku"));
        a.setNombre(str(d, "nombre"));
        if (a.getNombre() == null || a.getNombre().isBlank())
            throw new NegocioException("El nombre del artículo es requerido.");
        a.setDescripcion(str(d, "descripcion"));
        a.setPrecio(dec(d, "precio"));
        if (a.getPrecio() == null || a.getPrecio().signum() < 0)
            throw new NegocioException("El precio debe ser un número mayor o igual a 0.");
        Object st = d.get("stockTotal");
        a.setStockTotal(st instanceof Number n ? n.intValue() : 0);
        a.setDimensiones(str(d, "dimensiones"));
        a.setMaterial(str(d, "material"));
        a.setIncluye(str(d, "incluye"));
        a.setPesoMax(str(d, "pesoMax"));
        if (d.get("imagenUrl") != null) a.setImagenUrl(str(d, "imagenUrl"));
    }

    private void calcularDerivados(Connection con, Articulo a) throws SQLException {
        LocalDate hoy = LocalDate.now();
        int rentados = solicitudDao.unidadesOcupadas(con, a.getId(), hoy, hoy);
        a.setRentados(rentados);
        a.setStockDisponible(a.getStockTotal() - rentados);
        a.setStockBajo(a.getStockDisponible() <= UMBRAL_STOCK_BAJO);
    }

    private String str(Map<String, Object> d, String key) {
        Object v = d.get(key);
        return v == null ? null : v.toString();
    }

    private BigDecimal dec(Map<String, Object> d, String key) {
        Object v = d.get(key);
        if (v == null) return null;
        return new BigDecimal(v.toString());
    }
}
