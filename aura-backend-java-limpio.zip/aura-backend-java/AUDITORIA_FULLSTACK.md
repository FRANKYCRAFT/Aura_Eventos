# Auditoría de Alineación Full-Stack — Aura Eventos

**Objetivo:** verificar que los modelos del Front-End (localStorage), las tablas de MySQL
(`database.sql`) y los modelos de Java coinciden en nombres, tipos y reglas de negocio, para
que la migración de localStorage a la API sea un reemplazo directo.

> **Nota de tecnología:** la API es **Java puro (JDK) con POO**, sin frameworks. El acceso a
> datos es JDBC directo (clases DAO con `PreparedStatement`), la serialización es una
> librería JSON propia y el servidor es `com.sun.net.httpserver`. Donde este documento
> menciona "entidad"/"JPA"/"Hibernate" de una versión anterior, léase "modelo + DAO JDBC":
> los mapeos de nombres y tipos de las tablas siguientes son idénticos y siguen vigentes.

**Convención de nombres adoptada (estándar en cada tecnología):**

| Capa | Convención | Ejemplo |
|---|---|---|
| Front-End (JS / JSON) | camelCase | `stockTotal` |
| MySQL (columnas) | snake_case | `stock_total` |
| Java (atributos) | camelCase + `@Column(name="...")` | `stockTotal` mapeado a `stock_total` |

El JSON que produce la API usa camelCase (Jackson serializa los atributos Java tal cual),
por lo que **el Front-End recibe exactamente los mismos nombres de campo que hoy lee del
localStorage**. Ese es el criterio de alineación de toda la auditoría.

---

## 1. Matriz de mapeo: USUARIOS

localStorage `aura_users` · tabla `usuarios` · entidad `Usuario`

| Front-End (JS) | Tipo JS | Columna MySQL | Tipo SQL | Atributo Java | Tipo Java | ¿Alineado? |
|---|---|---|---|---|---|---|
| `id` | string `'u001'` | `id` | VARCHAR(20) PK | `id` | String | Sí |
| `nombre` | string | `nombre` | VARCHAR(60) | `nombre` | String | Sí |
| `apellidos` | string | `apellidos` | VARCHAR(80) NULL | `apellidos` | String | Sí |
| `email` | string | `email` | VARCHAR(120) UNIQUE | `email` | String | Sí |
| `password` | string (texto plano) | `password_hash` | VARCHAR(255) | `passwordHash` | String + `@JsonIgnore` | Sí — ver nota |
| `rol` | `'admin'`/`'cliente'` | `rol` | ENUM('admin','cliente') | `rol` | enum `Usuario.Rol` | Sí |
| `avatar` | string `'MG'` | `avatar` | VARCHAR(4) | `avatar` | String | Sí |
| `telefono` | string | `telefono` | VARCHAR(20) | `telefono` | String | Sí |
| — | — | `creado_en` | DATETIME | `creadoEn` | LocalDateTime | Campo nuevo del backend |

> **Nota de seguridad:** el Front-End guardaba la contraseña en texto plano (aceptable solo
> como demo). En el backend se almacena únicamente el hash BCrypt y `@JsonIgnore` garantiza
> que jamás viaje en las respuestas JSON. El login deja de comparar texto y pasa a
> `BCryptPasswordEncoder.matches()`.

---

## 2. Matriz de mapeo: CATEGORÍAS

localStorage `aura_categorias` (arreglo de strings) · tabla `categorias` · entidad `Categoria`

| Front-End (JS) | Columna MySQL | Atributo Java | ¿Alineado? |
|---|---|---|---|
| elemento del arreglo (string) | `nombre` VARCHAR(40) UNIQUE | `nombre` String | Sí |
| — (no existía) | `id` INT AUTO_INCREMENT PK | `id` Integer | Campo nuevo (llave sustituta) |

> **Decisión 3FN:** en el Front la categoría era un texto repetido dentro de cada artículo
> (dependencia transitiva y riesgo de inconsistencia al renombrar). Se extrajo a su propia
> tabla; los artículos ahora la referencian por `categoria_id`. La regla del Front de
> máximo 40 caracteres se conservó como `VARCHAR(40)` y como validación en
> `CategoriaServiceImpl`.

---

## 3. Matriz de mapeo: ARTÍCULOS

localStorage `aura_articulos` · tabla `articulos` · entidad `Articulo`

| Front-End (JS) | Tipo JS | Columna MySQL | Tipo SQL | Atributo Java | Tipo Java | ¿Alineado? |
|---|---|---|---|---|---|---|
| `id` | string `'art001'` | `id` | VARCHAR(20) PK | `id` | String | Sí |
| `sku` | string | `sku` | VARCHAR(20) UNIQUE | `sku` | String | Sí |
| `nombre` | string | `nombre` | VARCHAR(120) | `nombre` | String | Sí |
| `categoria` | string (nombre) | `categoria_id` | INT FK → categorias | `categoria` | objeto `Categoria` | Sí — ver nota |
| `descripcion` | string | `descripcion` | TEXT | `descripcion` | String | Sí |
| `precio` | number | `precio` | DECIMAL(10,2) | `precio` | BigDecimal | Sí |
| `stockTotal` | number | `stock_total` | INT UNSIGNED | `stockTotal` | Integer | Sí |
| `stockDisponible` | number **almacenado** | — **derivado** (vista) | — | `stockDisponible` | Integer `@Transient` | Sí — ver nota |
| `rentados` | number **almacenado** | — **derivado** (vista) | — | `rentados` | Integer `@Transient` | Sí — ver nota |
| `stockBajo` | boolean **almacenado** | — **derivado** (vista) | — | `stockBajo` | Boolean `@Transient` | Sí — ver nota |
| `masRentado` | boolean (flag seed) | — **derivado** | — | — (analíticas) | — | Derivado, no se persiste |
| `estado` | `'activo'`/`'deshabilitado'` | `estado` | ENUM(...) | `estado` | enum `Articulo.Estado` | Sí |
| `dimensiones` | string | `dimensiones` | VARCHAR(80) | `dimensiones` | String | Sí |
| `material` | string | `material` | VARCHAR(80) | `material` | String | Sí |
| `incluye` | string | `incluye` | VARCHAR(120) | `incluye` | String | Sí |
| `pesoMax` | string `'80 kg'` | `peso_max` | VARCHAR(20) | `pesoMax` | String | Sí |
| `rating` | number 4.9 | `rating` | DECIMAL(2,1) | `rating` | BigDecimal | Sí |
| `reviews` | number | `reviews` | INT UNSIGNED | `reviews` | Integer | Sí |
| `imagen` | string base64/URL | `imagen_url` | TEXT | `imagenUrl` | String | Renombrado — ver nota |

> **Nota categoría:** el JSON de salida de la API entrega la categoría como objeto
> `{ "id": 1, "nombre": "Mesa Candy" }`. En el Front, donde antes se leía `a.categoria`,
> ahora se lee `a.categoria.nombre` (único ajuste de este módulo al conectar la API).
>
> **Nota derivados:** `stockDisponible`/`rentados`/`stockBajo` eran datos almacenados en el
> Front, lo que violaba 3FN y podía quedar inconsistente. Ahora la única fuente de verdad es
> `stock_total` + solicitudes aprobadas vigentes: MySQL los expone en
> `vista_stock_articulos` y la API los calcula en `ArticuloServiceImpl.calcularDerivados()`
> (umbral de stock bajo: ≤ 3, igual que el Front). El JSON conserva los mismos nombres, así
> que el Front no cambia.
>
> **Nota imagen:** `imagen` → `imagen_url`/`imagenUrl` para reflejar que en producción se
> guarda una URL (o base64 en demo).

---

## 4. Matriz de mapeo: SOLICITUDES

localStorage `aura_solicitudes` · tablas `solicitudes` + `solicitud_articulos` ·
entidades `Solicitud` + `SolicitudArticulo`

| Front-End (JS) | Tipo JS | Columna MySQL | Tipo SQL | Atributo Java | Tipo Java | ¿Alineado? |
|---|---|---|---|---|---|---|
| `id` | string `'AUR-2025-0801'` | `id` | VARCHAR(20) PK | `id` | String | Sí |
| `clienteId` | string `'u002'` | `cliente_id` | VARCHAR(20) FK → usuarios | `cliente` | objeto `Usuario` | Sí — JSON expone el objeto |
| `fecha` | string ISO `'2025-07-05'` | `fecha_evento` | DATE | `fechaEvento` | LocalDate | Renombrado — ver nota |
| `fechaFin` | string ISO | `fecha_fin` | DATE + CHECK ≥ fecha_evento | `fechaFin` | LocalDate | Sí |
| `articulos` | arreglo `[{artId, cantidad}]` | tabla `solicitud_articulos` | filas N:M | `articulos` | `List<SolicitudArticulo>` | Sí — ver nota |
| `subtotal` | number | `subtotal` | DECIMAL(10,2) | `subtotal` | BigDecimal | Sí |
| `iva` | number (16 %) | `iva` | DECIMAL(10,2) | `iva` | BigDecimal | Sí — misma tasa 0.16 |
| `flete` | number o `null` | `flete` | DECIMAL(10,2) NULL | `flete` | BigDecimal | Sí — `null` = sin asignar en las 3 capas |
| `total` | number | `total` | DECIMAL(10,2) | `total` | BigDecimal | Sí |
| `estado` | `'pendiente'/'aprobado'/'rechazado'` | `estado` | ENUM(...) | `estado` | enum `Solicitud.Estado` | Sí |
| `direccion` | string | `direccion` | VARCHAR(255) | `direccion` | String | Sí |
| `notas` | string | `notas` | TEXT | `notas` | String | Sí |
| `motivoRechazo` | string | `motivo_rechazo` | TEXT | `motivoRechazo` | String | Sí |
| `createdAt` | string fecha | `creado_en` | DATETIME | `creadoEn` | LocalDateTime | Renombrado a español — ver nota |
| `aprobadoAt` | string fecha | `aprobado_en` | DATETIME NULL | `aprobadoEn` | LocalDateTime | Renombrado a español |

**Detalle del renglón (`solicitud_articulos` / `SolicitudArticulo`):**

| Front-End (JS) | Columna MySQL | Atributo Java | ¿Alineado? |
|---|---|---|---|
| `artId` | `articulo_id` FK → articulos | `articulo` (objeto) | Sí |
| `cantidad` | `cantidad` INT + CHECK > 0 | `cantidad` Integer | Sí |
| `precioSnapshot` (solo en carrito) | `precio_unitario` DECIMAL(10,2) | `precioUnitario` BigDecimal | Sí — snapshot histórico |

> **Nota `fecha` → `fechaEvento`:** en SQL "fecha" a secas es ambiguo junto a `fecha_fin` y
> `creado_en`, así que la columna se llama `fecha_evento`. El DTO de entrada
> (`SolicitudRequest`) **conserva el nombre `fecha`** que envía el Front, y el servicio hace
> la traducción — el Front no necesita cambiar su payload.
>
> **Nota arreglo embebido:** guardar los artículos dentro de la solicitud violaba 1FN
> (atributo multivaluado). La tabla puente los normaliza y además congela
> `precio_unitario`: si mañana cambia el precio del catálogo, las solicitudes históricas no
> se alteran (el Front ya hacía esto con `precioSnapshot` en el carrito).
>
> **Nota timestamps:** `createdAt`/`aprobadoAt` pasaron a `creadoEn`/`aprobadoEn` para
> mantener el esquema 100 % en español, consistente con el resto de columnas.

---

## 5. Matriz de mapeo: RECUPERACIÓN DE CONTRASEÑA

localStorage `aura_password_resets` · tabla `password_resets` · entidad `PasswordReset`

| Front-End (JS) | Columna MySQL | Atributo Java | ¿Alineado? |
|---|---|---|---|
| `email` | `usuario_id` FK → usuarios | `usuario` (objeto) | Sí — el backend referencia por FK, más robusto |
| `code` (6 dígitos) | `codigo` VARCHAR(64) | `codigo` String | Sí |
| `expiresAt` (epoch ms, +10 min) | `expira_en` DATETIME (+10 min) | `expiraEn` LocalDateTime | Sí — misma vigencia |
| `used` boolean | `usado` TINYINT(1) | `usado` Boolean | Sí — un solo uso en las 3 capas |

**Endpoints que respaldan cada paso del wizard `recuperar.html`:**

| Paso del Front | Método del Store (demo) | Endpoint real |
|---|---|---|
| 1. Enviar código | `Store.Auth.requestReset(email)` | `POST /api/auth/forgot-password` |
| 2. Verificar código | `Store.Auth.verifyResetCode(email, code)` | validación dentro de reset-password |
| 3. Nueva contraseña | `Store.Auth.resetPassword(email, code, pass)` | `POST /api/auth/reset-password` |
| Admin: restablecer | `Store.Auth.adminResetPassword(userId)` | `POST /api/usuarios/{id}/reset-password` |

---

## 6. Reglas de negocio replicadas (paridad de comportamiento)

| Regla | Front-End | MySQL | API Java |
|---|---|---|---|
| IVA 16 % | `Math.round(sub*0.16)` | dato calculado al insertar | `TASA_IVA = 0.16`, redondeo HALF_UP |
| Anti-overbooking | `disponibleParaFecha()` cruza aprobadas con traslape de fechas | `vista_stock_articulos` (aprobadas vigentes) | `SolicitudRepository.unidadesOcupadas()` (JPQL con la misma condición de traslape) |
| Flete obligatorio al aprobar | valida input antes de `aprobar()` | `flete` NULL = sin asignar | `NegocioException` si flete null/negativo |
| Solo pendientes se aprueban/rechazan | UI oculta botones | — | validación de estado en `SolicitudServiceImpl` |
| Categoría en uso no se elimina | `Categorias.remove()` cuenta artículos | FK `ON DELETE RESTRICT` | `CategoriaServiceImpl` + la FK como segunda barrera |
| Categoría máx. 40 caracteres | validación en `add()` | `VARCHAR(40)` | validación en servicio |
| Folio `AUR-YYYY-XXXX` | `'AUR-'+año+'-'+random(1000-9999)` | VARCHAR(20) PK | `generarFolio()` con verificación de unicidad |
| Correo único | `register()` busca duplicado | `UNIQUE KEY` | `existsByEmailIgnoreCase` + UNIQUE como respaldo |
| Código de recuperación: 6 dígitos, 10 min, un uso | implementado | tabla `password_resets` | implementado |
| Contraseña mínimo 6 caracteres | validación en wizard | — | `@Size(min = 6)` en DTOs |
| `fecha_fin ≥ fecha_evento` | el calendario lo impide | `CHECK` constraint | validación en servicio |

---

## 7. Casos de prueba de caja negra (QA)

Para auditar que la información fluye sin errores entre el Front, la API y la base de datos.
Cada caso indica entrada → salida esperada, sin conocer la implementación interna.

### Autenticación

| # | Caso | Entrada | Resultado esperado |
|---|---|---|---|
| CP-01 | Login válido | `POST /api/auth/login` con `admin@aura.mx` / `admin123` | 200, JSON del usuario con `rol:"admin"`, **sin** campo de contraseña |
| CP-02 | Login con contraseña errónea | mismo correo, password `xxx` | 400, `{"ok":false,"error":"Correo o contraseña incorrectos."}` |
| CP-03 | Registro con correo duplicado | `POST /api/auth/registro` con `maria@gmail.com` | 400, error "Este correo ya está registrado." |
| CP-04 | Registro con contraseña corta | password de 4 caracteres | 400, mensaje de mínimo 6 caracteres |

### Recuperación de contraseña

| # | Caso | Entrada | Resultado esperado |
|---|---|---|---|
| CP-05 | Solicitar código con correo inexistente | `POST /forgot-password` con `nadie@x.com` | 404, "No existe una cuenta registrada con ese correo." |
| CP-06 | Restablecer con código inválido | código `000000` no emitido | 400, "El código ingresado no es válido." |
| CP-07 | Reutilizar un código ya usado | mismo código dos veces | 1.ª vez 200; 2.ª vez 400 "ya fue utilizado" |
| CP-08 | Código expirado | esperar > 10 min (o ajustar `expira_en` en BD) | 400, "El código expiró." |
| CP-09 | Login tras restablecer | nueva contraseña en `/login` | 200 — y la contraseña anterior debe fallar |
| CP-10 | Reset por admin | `POST /api/usuarios/u002/reset-password` | 200 con `tempPassword` formato `Aura-XXXXXX`; login con ella funciona |

### Inventario y categorías

| # | Caso | Entrada | Resultado esperado |
|---|---|---|---|
| CP-11 | Catálogo público | `GET /api/articulos` | 200, solo artículos `estado:"activo"`, cada uno con `stockDisponible`, `rentados`, `stockBajo` calculados |
| CP-12 | SKU duplicado | `POST /api/articulos` con `sku:"MC-001-ORO"` | 400, "Ya existe un artículo con ese SKU." |
| CP-13 | Crear artículo con categoría inexistente | `categoriaId=999` | 404, "Categoría no encontrada." |
| CP-14 | Eliminar categoría en uso | `DELETE /api/categorias/1` (Mesa Candy tiene 4 artículos) | 400, "No se puede eliminar: 4 artículos usan esta categoría." |
| CP-15 | Eliminar categoría libre | `DELETE /api/categorias/6` (Backdrop, sin artículos) | 200, y desaparece de `GET /api/categorias` |

### Solicitudes (agenda)

| # | Caso | Entrada | Resultado esperado |
|---|---|---|---|
| CP-16 | Crear solicitud válida | `POST /api/solicitudes` con art007 x1, fecha libre | 201, folio `AUR-2025-XXXX`, `estado:"pendiente"`, `flete:null`, `total = subtotal + iva` |
| CP-17 | Overbooking | solicitar art006 x3 en fechas donde ya hay 3 aprobadas | 400, mensaje "no está disponible para la fecha seleccionada" |
| CP-18 | Fechas invertidas | `fechaFin` anterior a `fecha` | 400 (servicio) — y si se fuerza por SQL directo, el CHECK de MySQL lo rechaza |
| CP-19 | Aprobar sin flete | `PATCH /{id}/aprobar` con body vacío | 400, "Ingresa el costo de flete antes de aprobar." |
| CP-20 | Aprobar con flete | `PATCH /{id}/aprobar` `{"flete":450}` | 200, `estado:"aprobado"`, `total` incrementado en 450, `aprobadoEn` con timestamp |
| CP-21 | Aprobar dos veces | repetir CP-20 | 400, "Solo se pueden aprobar solicitudes pendientes." |
| CP-22 | Rechazar con motivo | `PATCH /{id}/rechazar` `{"motivo":"Fuera de área"}` | 200, `estado:"rechazado"`, `motivoRechazo` guardado |
| CP-23 | Stock se libera al rechazar | consultar `GET /api/articulos/{id}` antes y después | `stockDisponible` regresa al valor previo |

### Integridad referencial (directo en MySQL)

| # | Caso | Sentencia | Resultado esperado |
|---|---|---|---|
| CP-24 | FK de solicitud huérfana | `INSERT INTO solicitudes (... cliente_id='u999' ...)` | Error 1452 (FK constraint fails) |
| CP-25 | Borrar usuario con solicitudes | `DELETE FROM usuarios WHERE id='u002'` | Error 1451 (RESTRICT lo impide) |
| CP-26 | Borrar solicitud en cascada | `DELETE FROM solicitudes WHERE id='AUR-2025-0801'` | Sus 2 filas de `solicitud_articulos` se eliminan solas (CASCADE) |
| CP-27 | Renglón duplicado | insertar dos veces el mismo `(solicitud_id, articulo_id)` | Error 1062 (UNIQUE constraint) |
| CP-28 | Vista de stock | `SELECT * FROM vista_stock_articulos WHERE id='art003'` | `stock_disponible = stock_total - rentados` y `stock_bajo = 1` si ≤ 3 |

---

## 8. Conclusión de la auditoría

Los tres niveles del sistema quedaron alineados bajo un mismo contrato de datos: los nombres
camelCase que el Front-End ya consume son exactamente los que la API produce, las columnas
snake_case quedan encapsuladas detrás de los mapeos `@Column`, y las reglas de negocio
(IVA, overbooking, flete, folios, unicidad) existen en las tres capas con la base de datos
como última línea de defensa (FKs, UNIQUE, CHECK). Los únicos cambios que el Front
necesitará al conectar la API son dos y están documentados: leer `categoria.nombre` en vez
de `categoria`, y recibir `cliente` como objeto en vez de `clienteId` plano — todo lo demás
es un reemplazo directo de `Store.*` por `fetch()` a los endpoints equivalentes.
