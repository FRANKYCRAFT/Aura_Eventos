
const Store = (() => {

  const SEED = {
    users: [
      { id:'u001', nombre:'Ana', apellidos:'Martínez', email:'admin@aura.mx', password:'admin123', rol:'admin', avatar:'AM', telefono:'55 0000 0001' },
      { id:'u002', nombre:'María', apellidos:'García López', email:'maria@gmail.com', password:'maria123', rol:'cliente', avatar:'MG', telefono:'55 9876 5432' }
    ],
    articulos: [
      { id:'art001', sku:'MC-001-ORO', nombre:'Mesa Candy Premium Dorada', categoria:'Mesa Candy',
        descripcion:'Mesa decorativa de madera blanca con herrajes dorados. Perfecta para exposición de postres, dulces y bebidas. Incluye mantel de organza, faldón y 2 niveles de exhibición iluminados con tira LED cálida.',
        precio:1200, stockTotal:12, stockDisponible:10, rentados:2, estado:'activo',
        dimensiones:'1.8m × 0.6m × 0.9m', material:'MDF lacado blanco', incluye:'Montaje + desmontaje', pesoMax:'80 kg', rating:4.9, reviews:124, masRentado:true },
      { id:'art002', sku:'AG-002-PAS', nombre:'Arco Orgánico Pastel XL', categoria:'Arco de Globos',
        descripcion:'Arco de globos orgánico en tonos pastel. Incluye instalación y desmontaje. Totalmente personalizable.',
        precio:850, stockTotal:8, stockDisponible:7, rentados:1, estado:'activo',
        dimensiones:'2.5m × 0.8m', material:'Globos látex', incluye:'Instalación + desmontaje', rating:4.7, reviews:89 },
      { id:'art003', sku:'LN-003-RSA', nombre:'Letrero LED "LOVE" Rosa', categoria:'Letrero Neon',
        descripcion:'Letrero neón flexible con cable 3m. Brillo ajustable. Ideal para fondos fotográficos.',
        precio:650, stockTotal:5, stockDisponible:3, rentados:2, estado:'activo',
        dimensiones:'60cm × 30cm', material:'Neón LED', incluye:'Soporte + cable', stockBajo:true, rating:4.8, reviews:67 },
      { id:'art004', sku:'SC-004-BLA', nombre:'Sillas Chiavari Blancas x10', categoria:'Sillas & Mesas',
        descripcion:'Set de 10 sillas con cojín satinado. Perfectas para ceremonias y banquetes formales.',
        precio:2400, stockTotal:15, stockDisponible:12, rentados:3, estado:'activo',
        dimensiones:'Estándar', material:'Resina premium', incluye:'Cojines incluidos', rating:4.6, reviews:112 },
      { id:'art005', sku:'SL-005-BLA', nombre:'Set Lounge Blanco Moderno', categoria:'Lounge',
        descripcion:'Sofá 3 plazas, 2 sillones y mesa de centro. Ideal para áreas VIP y lounges de eventos.',
        precio:3500, stockTotal:6, stockDisponible:4, rentados:2, estado:'activo',
        dimensiones:'Conjunto completo', material:'Tapizado blanco', incluye:'Mesa de centro', rating:4.9, reviews:43 },
      { id:'art006', sku:'CV-006-VIN', nombre:'Carrito Vintage para Dulces', categoria:'Mesa Candy',
        descripcion:'Carrito de madera blanca con ruedas doradas. Incluye faldón y decoración base. Alta capacidad.',
        precio:1800, stockTotal:3, stockDisponible:3, rentados:0, estado:'activo',
        dimensiones:'1.2m × 0.6m × 1.4m', material:'Madera pintada', incluye:'Decoración base', rating:4.5, reviews:31 },
      { id:'art007', sku:'TC-007-3NV', nombre:'Torre de Cupcakes 3 Niveles', categoria:'Mesa Candy',
        descripcion:'Torre acrílica para 40+ cupcakes en 3 niveles. Plateada o dorada. Totalmente personalizable.',
        precio:950, stockTotal:8, stockDisponible:8, rentados:0, estado:'activo',
        dimensiones:'30cm diámetro × 60cm alto', material:'Acrílico', incluye:'Bases intercambiables', rating:4.4, reviews:55 },
      { id:'art008', sku:'FC-008-CHO', nombre:'Fuente de Chocolate Premium', categoria:'Mesa Candy',
        descripcion:'Fuente 3 pisos con motor silencioso. Capacidad 4kg choc. Incluye fondue de fresa.',
        precio:1400, stockTotal:4, stockDisponible:4, rentados:0, estado:'activo',
        dimensiones:'40cm diámetro × 50cm alto', material:'Acero inoxidable', incluye:'Chocolate + accesorios', rating:4.7, reviews:78 }
    ],
    solicitudes: [
      { id:'AUR-2025-0801', clienteId:'u002', fecha:'2025-07-05', fechaFin:'2025-07-06',
        articulos:[{artId:'art004',cantidad:1},{artId:'art005',cantidad:1}],
        subtotal:5900, iva:944, flete:450, total:7294, estado:'aprobado',
        direccion:'Col. Santa Fe, CDMX', createdAt:'2025-06-20', aprobadoAt:'2025-06-21' },
      { id:'AUR-2025-0779', clienteId:'u002', fecha:'2025-06-28', fechaFin:'2025-06-28',
        articulos:[{artId:'art003',cantidad:1}],
        subtotal:650, iva:104, flete:300, total:1054, estado:'aprobado',
        direccion:'Col. Roma Norte, CDMX', createdAt:'2025-06-10', aprobadoAt:'2025-06-11' },
      { id:'AUR-2025-0755', clienteId:'u002', fecha:'2025-06-14', fechaFin:'2025-06-14',
        articulos:[{artId:'art001',cantidad:1},{artId:'art002',cantidad:1}],
        subtotal:2050, iva:328, flete:350, total:2728, estado:'rechazado',
        direccion:'Tlalnepantla, Edo. Méx', createdAt:'2025-06-01',
        motivoRechazo:'Fecha ya ocupada con otro evento aprobado en esa zona.' },
      { id:'AUR-2025-0847', clienteId:'u002', fecha:'2025-07-21', fechaFin:'2025-07-24',
        articulos:[{artId:'art001',cantidad:1},{artId:'art002',cantidad:1},{artId:'art003',cantidad:2}],
        subtotal:3350, iva:536, flete:null, total:3886, estado:'pendiente',
        direccion:'Col. Polanco, CDMX', createdAt:'2025-07-15' },
      { id:'AUR-2025-0820', clienteId:'u002', fecha:'2025-07-19', fechaFin:'2025-07-19',
        articulos:[{artId:'art005',cantidad:1}],
        subtotal:3500, iva:560, flete:null, total:4060, estado:'pendiente',
        direccion:'Col. Lomas, CDMX', createdAt:'2025-07-14' },
      { id:'AUR-2025-0830', clienteId:'u002', fecha:'2025-07-22', fechaFin:'2025-07-22',
        articulos:[{artId:'art004',cantidad:1}],
        subtotal:2400, iva:384, flete:null, total:2784, estado:'pendiente',
        direccion:'Col. Juárez, CDMX', createdAt:'2025-07-15' }
    ]
  };

  function init() {
    if (!localStorage.getItem('aura_initialized')) {
      localStorage.setItem('aura_users',       JSON.stringify(SEED.users));
      localStorage.setItem('aura_articulos',   JSON.stringify(SEED.articulos));
      localStorage.setItem('aura_solicitudes', JSON.stringify(SEED.solicitudes));
      localStorage.setItem('aura_initialized', 'true');
    }
  }

  function get(key)      { try { return JSON.parse(localStorage.getItem(key) || '[]'); } catch(e){ return []; } }
  function set(key, val) { localStorage.setItem(key, JSON.stringify(val)); }

  const Auth = {
    login(email, password) {
      const user = get('aura_users').find(u => u.email === email && u.password === password);
      if (!user) return null;
      const sessionData = {
        id: user.id, nombre: user.nombre, apellidos: user.apellidos,
        email: user.email, rol: user.rol,
        avatar: user.avatar || (user.nombre[0] + (user.apellidos ? user.apellidos[0] : '')).toUpperCase(),
        telefono: user.telefono || ''
      };
      localStorage.setItem('aura_session', JSON.stringify(sessionData));
      return sessionData;
    },
    logout() {
      localStorage.removeItem('aura_session');
      localStorage.removeItem('aura_carrito');
    },
    session() {
      try { return JSON.parse(localStorage.getItem('aura_session') || 'null'); }
      catch(e) { return null; }
    },
    register(data) {
      const users = get('aura_users');
      if (users.find(u => u.email === data.email)) return { error: 'Este correo ya está registrado.' };
      const newUser = {
        id: 'u' + Date.now(),
        nombre: data.nombre, apellidos: data.apellidos,
        email: data.email, password: data.password,
        rol: 'cliente', telefono: data.telefono || '',
        avatar: (data.nombre[0] + (data.apellidos ? data.apellidos[0] : '')).toUpperCase()
      };
      users.push(newUser);
      set('aura_users', users);
      return { user: newUser };
    },

    requireAuth(rol = null) {
      const s = this.session();
      const inViews = window.location.pathname.includes('/views/');
      const loginUrl = inViews ? '../login.html' : 'login.html';

      if (!s) {
        window.location.href = loginUrl;
        return null;
      }
      if (rol && s.rol !== rol) {
        if (s.rol === 'admin') {
          window.location.href = inViews ? 'dashboard-admin.html' : 'views/dashboard-admin.html';
        } else {
          window.location.href = inViews ? 'dashboard-cliente.html' : 'views/dashboard-cliente.html';
        }
        return null;
      }
      return s;
    },

    _RESET_KEY: 'aura_password_resets',
    _resetAll() {
      try { return JSON.parse(localStorage.getItem(this._RESET_KEY) || '[]'); }
      catch(e) { return []; }
    },
    _resetSave(list) { localStorage.setItem(this._RESET_KEY, JSON.stringify(list)); },

    requestReset(email) {
      email = (email || '').trim().toLowerCase();
      const user = get('aura_users').find(u => u.email.toLowerCase() === email);
      if (!user) return { error: 'No existe una cuenta registrada con ese correo.' };
      const code = String(Math.floor(100000 + Math.random() * 900000));
      const list = this._resetAll().filter(r => r.email !== email);
      list.push({
        email,
        code,
        expiresAt: Date.now() + 10 * 60 * 1000,
        used: false
      });
      this._resetSave(list);
      return { ok: true, code };
    },

    verifyResetCode(email, code) {
      email = (email || '').trim().toLowerCase();
      const r = this._resetAll().find(r => r.email === email && r.code === String(code).trim());
      if (!r)             return { error: 'El código ingresado no es válido.' };
      if (r.used)         return { error: 'Este código ya fue utilizado. Solicita uno nuevo.' };
      if (Date.now() > r.expiresAt) return { error: 'El código expiró. Solicita uno nuevo.' };
      return { ok: true };
    },

    resetPassword(email, code, newPassword) {
      const check = this.verifyResetCode(email, code);
      if (check.error) return check;
      if (!newPassword || newPassword.length < 6)
        return { error: 'La contraseña debe tener al menos 6 caracteres.' };

      email = email.trim().toLowerCase();
      const users = get('aura_users');
      const idx   = users.findIndex(u => u.email.toLowerCase() === email);
      if (idx < 0) return { error: 'Usuario no encontrado.' };
      users[idx].password = newPassword;
      set('aura_users', users);

      const list = this._resetAll();
      const r    = list.find(r => r.email === email && r.code === String(code).trim());
      if (r) r.used = true;
      this._resetSave(list);
      return { ok: true };
    },

    adminResetPassword(userId) {
      const users = get('aura_users');
      const idx   = users.findIndex(u => u.id === userId);
      if (idx < 0) return { error: 'Usuario no encontrado.' };
      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
      let temp = 'Aura-';
      for (let i = 0; i < 6; i++) temp += chars[Math.floor(Math.random() * chars.length)];
      users[idx].password = temp;
      set('aura_users', users);
      return { ok: true, tempPassword: temp, user: users[idx] };
    }
  };

  const Articulos = {
    all()      { return get('aura_articulos').filter(a => a.estado === 'activo'); },
    allAdmin() { return get('aura_articulos'); },
    byId(id)   { return get('aura_articulos').find(a => a.id === id) || null; },

    create(data) {
      const arts = get('aura_articulos');
      const a = {
        id: 'art' + Date.now(), ...data,
        stockDisponible: data.stockTotal,
        rentados: 0, estado: 'activo',
        rating: 5.0, reviews: 0
      };
      arts.push(a);
      set('aura_articulos', arts);
      return a;
    },
    update(id, data) {
      const arts = get('aura_articulos');
      const idx  = arts.findIndex(a => a.id === id);
      if (idx < 0) return null;

      if (data.stockTotal !== undefined && data.stockTotal !== arts[idx].stockTotal) {
        const diff = data.stockTotal - arts[idx].stockTotal;
        data.stockDisponible = Math.max(0, arts[idx].stockDisponible + diff);
      }

      if (data.imagen === null && arts[idx].imagen) {
        delete data.imagen;
      }
      arts[idx] = { ...arts[idx], ...data };
      set('aura_articulos', arts);
      return arts[idx];
    },
    deshabilitar(id) { return this.update(id, { estado: 'inactivo' }); },
    habilitar(id)    { return this.update(id, { estado: 'activo' }); },

    disponibleParaFecha(artId, fecha, fechaFin, cantidad = 1) {
      const art = this.byId(artId);
      if (!art || art.estado !== 'activo') return false;
      const ocupado = get('aura_solicitudes')
        .filter(s => s.estado === 'aprobado')
        .reduce((total, s) => {
          const overlap = s.fecha <= (fechaFin || fecha) && (s.fechaFin || s.fecha) >= fecha;
          if (!overlap) return total;
          const item = s.articulos.find(i => i.artId === artId);
          return total + (item ? item.cantidad : 0);
        }, 0);
      return (art.stockTotal - ocupado) >= cantidad;
    }
  };

  const Carrito = {
    get()      { try { return JSON.parse(localStorage.getItem('aura_carrito') || '[]'); } catch(e){ return []; } },
    _set(items){ localStorage.setItem('aura_carrito', JSON.stringify(items)); },

    agregar(artId, cantidad = 1) {
      const art = (window.Store ? window.Store.Articulos : Articulos).byId(artId);
      if (!art) return { error: 'Artículo no encontrado.' };
      const items   = this.get();
      const existing = items.find(i => i.artId === artId);
      const yaEnCarrito = existing ? existing.cantidad : 0;
      if (yaEnCarrito + cantidad > art.stockTotal)
        return { error: `Solo hay ${art.stockTotal} unidad${art.stockTotal!==1?'es':''} disponibles en inventario.` };
      if (existing) existing.cantidad += cantidad;
      else items.push({
        artId, cantidad,
        precioSnapshot: art.precio,
        nombre:         art.nombre,
        categoria:      art.categoria
      });
      this._set(items);
      return { ok: true, items };
    },
    actualizar(artId, cantidad) {
      const art = (window.Store ? window.Store.Articulos : Articulos).byId(artId);
      if (art && cantidad > art.stockTotal)
        return { error: `Solo hay ${art.stockTotal} unidades disponibles.` };
      const items = this.get().map(i => i.artId === artId ? { ...i, cantidad } : i).filter(i => i.cantidad > 0);
      this._set(items);
      return { ok: true, items };
    },
    eliminar(artId) { this._set(this.get().filter(i => i.artId !== artId)); },
    vaciar()        { localStorage.removeItem('aura_carrito'); },
    subtotal()      { return this.get().reduce((s, i) => s + i.precioSnapshot * i.cantidad, 0); },
    count()         { return this.get().reduce((s, i) => s + i.cantidad, 0); }
  };

  const Solicitudes = {
    all()              { return get('aura_solicitudes'); },
    byCliente(cId)     { return get('aura_solicitudes').filter(s => s.clienteId === cId); },
    byId(id)           { return get('aura_solicitudes').find(s => s.id === id) || null; },

    crear(data) {

      for (const item of data.articulos) {
        if (!Articulos.disponibleParaFecha(item.artId, data.fecha, data.fechaFin, item.cantidad)) {
          const art = Articulos.byId(item.artId);
          return { error: `"${art?.nombre||'Artículo'}" no está disponible para la fecha seleccionada. Por favor elige otra fecha.` };
        }
      }
      const solic    = get('aura_solicitudes');
      const subtotal = data.articulos.reduce((s, i) => {
        const a = Articulos.byId(i.artId);
        return s + (a ? a.precio * i.cantidad : 0);
      }, 0);
      const iva = Math.round(subtotal * 0.16);
      const id  = 'AUR-' + new Date().getFullYear() + '-' + String(Math.floor(Math.random()*9000)+1000);
      const nueva = {
        id, clienteId: data.clienteId,
        fecha: data.fecha, fechaFin: data.fechaFin || data.fecha,
        articulos: data.articulos,
        subtotal, iva, flete: null, total: subtotal + iva,
        estado: 'pendiente',
        direccion: data.direccion,
        notas: data.notas || '',
        createdAt: new Date().toISOString().split('T')[0]
      };
      solic.push(nueva);
      set('aura_solicitudes', solic);
      Carrito.vaciar();
      return { ok: true, solicitud: nueva };
    },

    aprobar(id, flete = 0) {
      const solic = get('aura_solicitudes');
      const idx   = solic.findIndex(s => s.id === id);
      if (idx < 0) return { error: 'Solicitud no encontrada.' };
      solic[idx].estado     = 'aprobado';
      solic[idx].flete      = Number(flete);
      solic[idx].total      = solic[idx].subtotal + solic[idx].iva + Number(flete);
      solic[idx].aprobadoAt = new Date().toISOString();
      set('aura_solicitudes', solic);
      return { ok: true, solicitud: solic[idx] };
    },

    rechazar(id, motivo = '') {
      const solic = get('aura_solicitudes');
      const idx   = solic.findIndex(s => s.id === id);
      if (idx < 0) return { error: 'Solicitud no encontrada.' };
      solic[idx].estado        = 'rechazado';
      solic[idx].motivoRechazo = motivo;
      set('aura_solicitudes', solic);
      return { ok: true };
    }
  };

  const Categorias = {
    _KEY: 'aura_categorias',
    _DEFAULTS: ['Mesa Candy','Arco de Globos','Letrero Neon','Sillas & Mesas','Lounge','Backdrop','Candy Bar'],

    all() {
      try {
        const raw = localStorage.getItem(this._KEY);
        if (!raw) { this._save([...this._DEFAULTS]); return [...this._DEFAULTS]; }
        return JSON.parse(raw);
      } catch(e) { return [...this._DEFAULTS]; }
    },
    _save(cats) { localStorage.setItem(this._KEY, JSON.stringify(cats)); },

    add(nombre) {
      nombre = nombre.trim();
      if (!nombre) return { error: 'El nombre no puede estar vacío.' };
      const cats = this.all();
      if (cats.some(c => c.toLowerCase() === nombre.toLowerCase()))
        return { error: 'Esta categoría ya existe.' };
      if (nombre.length > 40) return { error: 'Máximo 40 caracteres.' };
      cats.push(nombre);
      this._save(cats);
      return { ok: true };
    },

    remove(nombre) {
      const enUso = get('aura_articulos').filter(a => a.categoria === nombre);
      if (enUso.length > 0)
        return { error: `No se puede eliminar: ${enUso.length} artículo${enUso.length !== 1 ? 's' : ''} usan esta categoría.` };
      this._save(this.all().filter(c => c !== nombre));
      return { ok: true };
    },

    reset() {
      this._save([...this._DEFAULTS]);
      return [...this._DEFAULTS];
    }
  };

  return { init, Auth, Articulos, Carrito, Solicitudes, Categorias, get, set };
})();

Store.init();
