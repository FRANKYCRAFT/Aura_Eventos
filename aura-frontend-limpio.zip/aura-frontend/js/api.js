

const API_BASE = (['5500', '5501', '3000'].includes(window.location.port))
  ? 'http://localhost:8080/api'
  : '/api';

const API = (() => {

  const cache = {
    articulos:   [],
    solicitudes: [],
    usuarios:    [],
    categorias:  [],
    _catMap:     {}
  };

  async function req(path, options = {}) {
    let res;
    try {
      res = await fetch(API_BASE + path, {
        headers: { 'Content-Type': 'application/json' },
        ...options
      });
    } catch (e) {
      throw new Error('No se pudo conectar con el servidor. Verifica que la API esté en línea.');
    }
    let body = null;
    try { body = await res.json(); } catch (e) {  }
    if (!res.ok) {
      throw new Error((body && body.error) || `Error del servidor (${res.status}).`);
    }
    return body;
  }

  function normArt(a) {
    return {
      id:              a.id,
      sku:             a.sku,
      nombre:          a.nombre,
      categoria:       a.categoria ? a.categoria.nombre : '',
      _categoriaId:    a.categoria ? a.categoria.id : null,
      descripcion:     a.descripcion || '',
      precio:          Number(a.precio),
      stockTotal:      a.stockTotal,
      stockDisponible: a.stockDisponible,
      rentados:        a.rentados,
      stockBajo:       !!a.stockBajo,

      estado:          (a.estado === 'deshabilitado') ? 'inactivo' : a.estado,
      dimensiones:     a.dimensiones || '',
      material:        a.material || '',
      incluye:         a.incluye || '',
      pesoMax:         a.pesoMax || '',
      rating:          Number(a.rating || 5),
      reviews:         a.reviews || 0,
      imagen:          a.imagenUrl || null
    };
  }

  function normSol(s) {
    return {
      id:            s.id,
      clienteId:     s.cliente ? s.cliente.id : s.clienteId,
      clienteNombre: s.cliente ? `${s.cliente.nombre} ${s.cliente.apellidos || ''}`.trim() : '',
      fecha:         s.fechaEvento,
      fechaFin:      s.fechaFin,
      articulos:     (s.articulos || []).map(r => ({
                       artId:          r.articulo ? r.articulo.id : r.artId,
                       cantidad:       r.cantidad,
                       precioSnapshot: Number(r.precioUnitario)
                     })),
      subtotal:      Number(s.subtotal),
      iva:           Number(s.iva),
      flete:         s.flete === null || s.flete === undefined ? null : Number(s.flete),
      total:         Number(s.total),
      estado:        s.estado,
      direccion:     s.direccion || '',
      notas:         s.notas || '',
      motivoRechazo: s.motivoRechazo || null,
      createdAt:     s.creadoEn,
      aprobadoAt:    s.aprobadoEn || null
    };
  }

  function normUser(u) {
    return {
      id: u.id, nombre: u.nombre, apellidos: u.apellidos || '',
      email: u.email, rol: u.rol, avatar: u.avatar || '',
      telefono: u.telefono || ''
    };
  }

  async function init(needs = []) {
    const session = Store.Auth.session();
    const isAdmin = session && session.rol === 'admin';
    const jobs = [];

    if (needs.includes('articulos')) {
      jobs.push(req(isAdmin ? '/articulos/admin' : '/articulos')
        .then(list => { cache.articulos = list.map(normArt); }));
    }
    if (needs.includes('solicitudes')) {
      const path = isAdmin ? '/solicitudes' : `/solicitudes/cliente/${session.id}`;
      jobs.push(req(path)
        .then(list => { cache.solicitudes = list.map(normSol); }));
    }
    if (needs.includes('usuarios')) {
      jobs.push(req('/usuarios/clientes')
        .then(list => { cache.usuarios = list.map(normUser); }));
    }
    if (needs.includes('categorias')) {
      jobs.push(req('/categorias')
        .then(list => {
          cache.categorias = list.map(c => c.nombre);
          cache._catMap = {};
          list.forEach(c => { cache._catMap[c.nombre] = c.id; });
        }));
    }
    await Promise.all(jobs);
  }

  async function reloadCategorias() {
    const list = await req('/categorias');
    cache.categorias = list.map(c => c.nombre);
    cache._catMap = {};
    list.forEach(c => { cache._catMap[c.nombre] = c.id; });
  }

  function fatal(err) {
    console.error(err);
    const main = document.querySelector('.main-content') || document.body;
    main.insertAdjacentHTML('afterbegin', `
      <div class="alert alert-error" style="margin:1rem">
        <div class="alert-content">
          <div class="alert-title">Sin conexión con el servidor</div>
          ${err.message} — recarga la página cuando la API esté disponible.
        </div>
      </div>`);
  }

  return { init, reloadCategorias, req, cache, normArt, normSol, normUser, fatal };
})();

Store.Articulos = {
  all()      { return API.cache.articulos.filter(a => a.estado === 'activo'); },
  allAdmin() { return API.cache.articulos.slice(); },
  byId(id)   { return API.cache.articulos.find(a => a.id === id) || null; },

  _toBody(data) {
    return {
      sku:         data.sku,
      nombre:      data.nombre,
      descripcion: data.descripcion,
      precio:      data.precio,
      stockTotal:  data.stockTotal,
      dimensiones: data.dimensiones,
      material:    data.material,
      incluye:     data.incluye,
      pesoMax:     data.pesoMax,
      imagenUrl:   data.imagen || null
    };
  },

  async create(data) {
    try {
      const catId = API.cache._catMap[data.categoria];
      if (!catId) return { error: 'Selecciona una categoría válida.' };
      const nuevo = await API.req(`/articulos?categoriaId=${catId}`, {
        method: 'POST', body: JSON.stringify(this._toBody(data))
      });
      API.cache.articulos.push(API.normArt(nuevo));
      return { ok: true };
    } catch (e) { return { error: e.message }; }
  },

  async update(id, data) {
    try {
      const catId = API.cache._catMap[data.categoria];
      const q = catId ? `?categoriaId=${catId}` : '';
      const upd = await API.req(`/articulos/${id}${q}`, {
        method: 'PUT', body: JSON.stringify(this._toBody(data))
      });
      const i = API.cache.articulos.findIndex(a => a.id === id);
      if (i >= 0) API.cache.articulos[i] = API.normArt(upd);
      return { ok: true };
    } catch (e) { return { error: e.message }; }
  },

  async deshabilitar(id) {
    try {
      await API.req(`/articulos/${id}/deshabilitar`, { method: 'PATCH' });
      const a = this.byId(id); if (a) a.estado = 'inactivo';
      return { ok: true };
    } catch (e) { return { error: e.message }; }
  },

  async habilitar(id) {
    try {
      await API.req(`/articulos/${id}/habilitar`, { method: 'PATCH' });
      const a = this.byId(id); if (a) a.estado = 'activo';
      return { ok: true };
    } catch (e) { return { error: e.message }; }
  },

  async eliminar(id) {
    try {
      await API.req(`/articulos/${id}`, { method: 'DELETE' });
      API.cache.articulos = API.cache.articulos.filter(a => a.id !== id);
      return { ok: true };
    } catch (e) { return { error: e.message }; }
  }
};

Store.Categorias = {
  all() { return API.cache.categorias.slice(); },

  async add(nombre) {
    try {
      await API.req('/categorias', { method: 'POST', body: JSON.stringify({ nombre }) });
      await API.reloadCategorias();
      return { ok: true };
    } catch (e) { return { error: e.message }; }
  },

  async remove(nombre) {
    try {
      const id = API.cache._catMap[nombre];
      if (!id) return { error: 'Categoría no encontrada.' };
      await API.req(`/categorias/${id}`, { method: 'DELETE' });
      await API.reloadCategorias();
      return { ok: true };
    } catch (e) { return { error: e.message }; }
  }
};

Store.Solicitudes = {
  all()           { return API.cache.solicitudes.slice(); },
  byCliente(cid)  { return API.cache.solicitudes.filter(s => s.clienteId === cid); },
  byId(id)        { return API.cache.solicitudes.find(s => s.id === id) || null; },

  async crear(payload) {
    try {
      const nueva = await API.req('/solicitudes', {
        method: 'POST',
        body: JSON.stringify({
          clienteId: payload.clienteId,
          fecha:     payload.fecha,
          fechaFin:  payload.fechaFin || payload.fecha,
          direccion: payload.direccion,
          notas:     payload.notas || null,
          articulos: payload.articulos
        })
      });
      const n = API.normSol(nueva);
      API.cache.solicitudes.unshift(n);
      return { ok: true, solicitud: n, id: n.id };
    } catch (e) { return { error: e.message }; }
  },

  async aprobar(id, flete) {
    try {
      const upd = await API.req(`/solicitudes/${id}/aprobar`, {
        method: 'PATCH', body: JSON.stringify({ flete: Number(flete) || 0 })
      });
      const i = API.cache.solicitudes.findIndex(s => s.id === id);
      if (i >= 0) API.cache.solicitudes[i] = API.normSol(upd);
      return { ok: true };
    } catch (e) { return { error: e.message }; }
  },

  async rechazar(id, motivo) {
    try {
      const upd = await API.req(`/solicitudes/${id}/rechazar`, {
        method: 'PATCH', body: JSON.stringify({ motivo: motivo || '' })
      });
      const i = API.cache.solicitudes.findIndex(s => s.id === id);
      if (i >= 0) API.cache.solicitudes[i] = API.normSol(upd);
      return { ok: true };
    } catch (e) { return { error: e.message }; }
  }
};

Store.Usuarios = {
  clientes() { return API.cache.usuarios.slice(); },
  byId(id)   { return API.cache.usuarios.find(u => u.id === id) || null; },

  async actualizarPerfil(id, datos) {
    try {
      const u = await API.req(`/usuarios/${id}`, {
        method: 'PUT', body: JSON.stringify(datos)
      });
      return { ok: true, user: API.normUser(u) };
    } catch (e) { return { error: e.message }; }
  },

  async cambiarPassword(id, actual, nueva) {
    try {
      await API.req(`/usuarios/${id}/change-password`, {
        method: 'POST', body: JSON.stringify({ actual, nueva })
      });
      return { ok: true };
    } catch (e) { return { error: e.message }; }
  }
};

Store.Auth.login = async function (email, password) {
  try {
    const user = await API.req('/auth/login', {
      method: 'POST', body: JSON.stringify({ email, password })
    });
    localStorage.setItem('aura_session', JSON.stringify(API.normUser(user)));
    return API.normUser(user);
  } catch (e) { return { error: e.message }; }
};

Store.Auth.register = async function (datos) {
  try {
    const user = await API.req('/auth/registro', {
      method: 'POST',
      body: JSON.stringify({
        nombre: datos.nombre, apellidos: datos.apellidos,
        email: datos.email, password: datos.password, telefono: datos.telefono
      })
    });
    return { ok: true, user: API.normUser(user) };
  } catch (e) { return { error: e.message }; }
};

Store.Auth.requestReset = async function (email) {
  try {
    const r = await API.req('/auth/forgot-password', {
      method: 'POST', body: JSON.stringify({ email })
    });
    return { ok: true, code: r.dato ? r.dato.codigoDemo : null };
  } catch (e) { return { error: e.message }; }
};

Store.Auth.verifyResetCode = async function (email, codigo) {
  try {
    await API.req('/auth/verify-reset-code', {
      method: 'POST', body: JSON.stringify({ email, codigo: String(codigo) })
    });
    return { ok: true };
  } catch (e) { return { error: e.message }; }
};

Store.Auth.resetPassword = async function (email, codigo, nuevaPassword) {
  try {
    await API.req('/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ email, codigo: String(codigo), nuevaPassword })
    });
    return { ok: true };
  } catch (e) { return { error: e.message }; }
};

Store.Auth.adminResetPassword = async function (userId) {
  try {
    const r = await API.req(`/usuarios/${userId}/reset-password`, { method: 'POST' });
    return { ok: true, tempPassword: r.dato.tempPassword };
  } catch (e) { return { error: e.message }; }
};

