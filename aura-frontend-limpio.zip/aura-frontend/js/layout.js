

const IS_VIEWS = window.location.pathname.includes('/views/');
const BASE     = IS_VIEWS ? '' : 'views/';
const ROOT     = IS_VIEWS ? '../' : '';

function logoutConfirm() {
  UI.modal({
    title: 'Cerrar sesión',
    body: '<p style="color:var(--text-secondary)">¿Estás seguro de que deseas cerrar tu sesión?</p>',
    confirmLabel: 'Cerrar sesión',
    cancelLabel: 'Cancelar',
    confirmClass: 'btn-danger',
    onConfirm: () => { Store.Auth.logout(); window.location.href = ROOT + 'login.html'; }
  });
}

function renderSidebar(activeLink) {
  const s = Store.Auth.session();
  if (!s) { window.location.href = ROOT + 'login.html'; return; }

  const pending  = Store.Solicitudes.all().filter(x => x.estado === 'pendiente').length;
  const initials = s.avatar || (s.nombre[0] + (s.apellidos ? s.apellidos[0] : '')).toUpperCase();

  const logoImg = `<img src="${ROOT}assets/logo-placeholder.png" alt="Aura Eventos" class="sidebar-logo"
    onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
    <div class="sidebar-logo-fallback" style="display:none">
      <div class="logo-mark">A</div>
      <span class="logo-text">AURA <span>EVENTOS</span></span>
    </div>`;

  const adminLinks = `
    <span class="sidebar-label">Principal</span>
    <a href="${BASE}dashboard-admin.html" class="sidebar-link ${activeLink==='dashboard-admin'?'active':''}">
      ${Icons.get('grid',16)} Dashboard
    </a>
    <span class="sidebar-label" style="margin-top:.5rem">Gestión</span>
    <a href="${BASE}agenda.html" class="sidebar-link ${activeLink==='agenda'?'active':''}">
      ${Icons.get('calendar',16)} Agenda / Solicitudes
      ${pending>0?`<span class="badge-count">${pending}</span>`:''}
    </a>
    <a href="${BASE}inventario.html" class="sidebar-link ${activeLink==='inventario'?'active':''}">
      ${Icons.get('package',16)} Inventario
    </a>
    <a href="${BASE}clientes-admin.html" class="sidebar-link ${activeLink==='clientes-admin'?'active':''}">
      ${Icons.get('users',16)} Clientes
    </a>
    <span class="sidebar-label" style="margin-top:.5rem">Reportes</span>
    <a href="#" class="sidebar-link" onclick="exportarPDF(event)">
      ${Icons.get('file-text',16)} Exportar PDF
    </a>`;

  const clientLinks = `
    <span class="sidebar-label">Principal</span>
    <a href="${BASE}dashboard-cliente.html" class="sidebar-link ${activeLink==='dashboard-cliente'?'active':''}">
      ${Icons.get('grid',16)} Dashboard
    </a>
    <a href="${BASE}catalogo.html" class="sidebar-link ${activeLink==='catalogo'?'active':''}">
      ${Icons.get('tag',16)} Catálogo
    </a>
    <a href="${BASE}mis-solicitudes.html" class="sidebar-link ${activeLink==='mis-solicitudes'?'active':''}">
      ${Icons.get('file-text',16)} Mis Solicitudes
    </a>
    <a href="${BASE}mi-perfil.html" class="sidebar-link ${activeLink==='perfil'?'active':''}">
      ${Icons.get('user',16)} Mi Perfil
    </a>`;

  const el = document.getElementById('sidebar-mount');
  if (!el) return;
  el.innerHTML = `
    <div class="sidebar" id="sidebar">
      <div class="sidebar-logo-wrap">${logoImg}</div>
      ${s.rol==='admin'
        ? `<div class="sidebar-role-tag">Panel de Administración</div>`
        : ''}
      <div class="sidebar-section">
        ${s.rol==='admin' ? adminLinks : clientLinks}
      </div>
      <div class="sidebar-footer">
        <div class="sidebar-user" onclick="logoutConfirm()" title="Cerrar sesión">
          <div class="avatar" style="width:32px;height:32px;font-size:11px">${initials}</div>
          <div class="sidebar-user-info">
            <div class="sidebar-user-name">${s.nombre} ${s.apellidos||''}</div>
            <div class="sidebar-user-role">${s.rol==='admin'?'Administradora':'Cliente'}</div>
          </div>
          <span class="sidebar-logout-btn" title="Cerrar sesión">
            ${Icons.get('log-out',15,'sidebar-logout-icon')}
          </span>
        </div>
      </div>
    </div>`;
}

function renderTopnav(activeLink) {
  const s = Store.Auth.session();
  if (!s) { window.location.href = ROOT + 'login.html'; return; }

  const cartCount = Store.Carrito.count();
  const initials  = s.avatar || (s.nombre[0]+(s.apellidos?s.apellidos[0]:'')).toUpperCase();

  const el = document.getElementById('topnav-mount');
  if (!el) return;
  el.innerHTML = `
    <nav class="topnav">
      <div class="topnav-logo" onclick="window.location.href='${BASE}dashboard-cliente.html'">
        <img src="${ROOT}assets/logo-placeholder.png" alt="Aura Eventos" style="max-height:28px"
          onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
        <div style="display:none;align-items:center;gap:.4rem">
          <div class="logo-mark" style="width:24px;height:24px;font-size:.75rem">A</div>
          <span class="logo-text" style="font-size:.875rem">AURA <span>EVENTOS</span></span>
        </div>
      </div>
      <div class="topnav-links">
        <a href="${BASE}catalogo.html"        class="nav-link ${activeLink==='catalogo'?'active'       :''}">Catálogo</a>
        <a href="${BASE}mis-solicitudes.html" class="nav-link ${activeLink==='mis-solicitudes'?'active':''}">Mis Solicitudes</a>
      </div>
      <div class="topnav-actions">
        <div class="search-input-wrap">
          <span class="search-icon">${Icons.get('search',15)}</span>
          <input type="text" id="topnav-search" placeholder="Buscar artículos...">
        </div>
        <button class="btn btn-icon btn-ghost cart-btn" id="topnav-cart-btn" title="Mi carrito" style="position:relative;color:#94A3B8">
          ${Icons.get('cart',18)}
          <span class="cart-badge" id="topnav-cart-badge" style="display:${cartCount>0?'flex':'none'}">${cartCount||''}</span>
        </button>
        <div style="position:relative" id="user-menu-wrap">
          <div class="avatar" style="width:34px;height:34px;font-size:12px;cursor:pointer" id="user-avatar-btn"
               title="${s.nombre} — clic para opciones">${initials}</div>
          <div class="user-dropdown" id="user-dropdown">
            <div class="dropdown-header">
              <div style="font-weight:700;font-size:.875rem;color:var(--text-primary)">${s.nombre} ${s.apellidos||''}</div>
              <div style="font-size:.75rem;color:var(--text-muted)">${s.email}</div>
            </div>
            <a href="${BASE}dashboard-cliente.html" class="dropdown-item">${Icons.get('grid',14)} Mi Dashboard</a>
            <a href="${BASE}mis-solicitudes.html"   class="dropdown-item">${Icons.get('file-text',14)} Mis Solicitudes</a>
            <a href="${BASE}mi-perfil.html"         class="dropdown-item">${Icons.get('user',14)} Mi Perfil</a>
            <div class="dropdown-divider"></div>
            <button class="dropdown-item danger" onclick="logoutConfirm()">
              ${Icons.get('log-out',14)} Cerrar sesión
            </button>
          </div>
        </div>
      </div>
    </nav>`;

  document.getElementById('topnav-cart-btn').addEventListener('click', () => {
    if (typeof toggleCart === 'function') toggleCart();
    else window.location.href = BASE + 'catalogo.html';
  });

  document.getElementById('user-avatar-btn').addEventListener('click', e => {
    e.stopPropagation();
    document.getElementById('user-dropdown').classList.toggle('open');
  });
  document.addEventListener('click', () => {
    const dd = document.getElementById('user-dropdown');
    if (dd) dd.classList.remove('open');
  }, { capture: false });

  const si = document.getElementById('topnav-search');
  if (si) {
    si.addEventListener('keydown', e => {
      if (e.key === 'Enter' && si.value.trim())
        window.location.href = `${BASE}catalogo.html?q=${encodeURIComponent(si.value.trim())}`;
    });
  }
}

function exportarPDF(e) {
  e && e.preventDefault();
  UI.toast('Generando reporte...', 'info');
  setTimeout(() => window.print(), 400);
}
