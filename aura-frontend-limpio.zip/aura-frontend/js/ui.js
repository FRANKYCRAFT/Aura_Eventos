
const UI = (() => {

  let _container = null;
  function _getContainer() {
    if (!_container || !document.body.contains(_container)) {
      _container = document.createElement('div');
      _container.style.cssText =
        'position:fixed;top:1rem;right:1rem;z-index:9999;display:flex;flex-direction:column;gap:.5rem;max-width:360px;pointer-events:none';
      document.body.appendChild(_container);
    }
    return _container;
  }

  function toast(message, type = 'success', duration = 4000) {
    const colors = {
      success: { bg:'#064e3b', border:'#10B981', icon:'✓',  iconColor:'#10B981' },
      error:   { bg:'#450a0a', border:'#ef4444', icon:'⊘',  iconColor:'#ef4444' },
      warning: { bg:'#431407', border:'#f59e0b', icon:'△',  iconColor:'#f59e0b' },
      info:    { bg:'#0c1a3a', border:'#3b82f6', icon:'ℹ', iconColor:'#3b82f6' }
    };
    const c = colors[type] || colors.info;
    const t = document.createElement('div');
    t.style.cssText = `background:${c.bg};border:1px solid ${c.border};border-radius:8px;padding:.75rem 1rem;
      display:flex;gap:.75rem;align-items:flex-start;box-shadow:0 4px 24px rgba(0,0,0,.5);
      pointer-events:all;cursor:pointer;animation:toastIn .22s ease;`;
    t.innerHTML = `
      <span style="color:${c.iconColor};font-size:1rem;flex-shrink:0;margin-top:1px">${c.icon}</span>
      <span style="color:#f8fafc;font-size:.875rem;line-height:1.4;flex:1">${message}</span>
      <span style="color:#94a3b8;flex-shrink:0;font-size:.9rem;line-height:1">✕</span>`;
    t.addEventListener('click', () => removeToast(t));
    _getContainer().appendChild(t);
    const timer = setTimeout(() => removeToast(t), duration);
    t.dataset.timer = timer;
  }

  function removeToast(t) {
    if (!t.parentElement) return;
    clearTimeout(Number(t.dataset.timer));
    t.style.animation = 'toastOut .18s ease forwards';
    setTimeout(() => t.remove(), 180);
  }

  function modal({ title, body, confirmLabel='Confirmar', cancelLabel='Cancelar', confirmClass='btn-primary', onConfirm, onCancel }) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-box" role="dialog" aria-modal="true" style="max-width:440px">
        <div class="modal-header">
          <h3 class="modal-title">${title}</h3>
          <button class="modal-close" aria-label="Cerrar">✕</button>
        </div>
        <div class="modal-body">${body}</div>
        <div class="modal-footer">
          <button class="btn btn-ghost modal-cancel">${cancelLabel}</button>
          <button class="btn ${confirmClass} modal-confirm">${confirmLabel}</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('active'));
    overlay.style.display = 'flex';

    const close = (cb) => {
      overlay.classList.remove('active');
      setTimeout(() => { overlay.remove(); cb && cb(); }, 200);
    };
    overlay.querySelector('.modal-close').onclick  = () => close(onCancel);
    overlay.querySelector('.modal-cancel').onclick = () => close(onCancel);
    overlay.querySelector('.modal-confirm').onclick= () => close(onConfirm);
    overlay.addEventListener('click', e => { if (e.target === overlay) close(onCancel); });
  }

  const MONTHS = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
  const fmt = {
    money(n) {
      return '$' + Number(n || 0).toLocaleString('es-MX', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    },
    date(d) {
      if (!d) return '—';
      const p = String(d).split('-');
      if (p.length < 3) return d;
      return `${parseInt(p[2])} ${MONTHS[parseInt(p[1])-1]} ${p[0]}`;
    },
    dateRange(d1, d2) {
      if (!d1) return '—';
      if (!d2 || d1 === d2) return fmt.date(d1);
      const p1 = d1.split('-'), p2 = d2.split('-');
      if (p1[0] === p2[0] && p1[1] === p2[1])
        return `${parseInt(p1[2])} – ${parseInt(p2[2])} ${MONTHS[parseInt(p1[1])-1]} ${p1[0]}`;
      return `${fmt.date(d1)} – ${fmt.date(d2)}`;
    },
    days(d1, d2) {
      if (!d1) return 1;
      if (!d2 || d1 === d2) return 1;
      const a = new Date(d1 + 'T00:00:00'), b = new Date(d2 + 'T00:00:00');
      return Math.max(1, Math.round((b - a) / 86400000) + 1);
    }
  };

  function statusBadge(estado) {
    const map = {
      pendiente:  { label:'PENDIENTE',  cls:'badge-pending'  },
      aprobado:   { label:'APROBADO',   cls:'badge-approved' },
      rechazado:  { label:'RECHAZADO',  cls:'badge-rejected' },
      incompleto: { label:'INCOMPLETO', cls:'badge-incomplete'}
    };
    const s = map[estado] || { label: estado?.toUpperCase()||'', cls:'' };
    return `<span class="badge ${s.cls}">● ${s.label}</span>`;
  }

  const CAT_ICONS = {
    'Mesa Candy':'🍬','Arco de Globos':'🎈','Letrero Neon':'💡',
    'Sillas & Mesas':'🪑','Lounge':'🛋️','Backdrop':'🌸','Candy Bar':'🍭'
  };
  function catIcon(cat) { return CAT_ICONS[cat] || '📦'; }

  function updateCartBadge() {
    const count = Store.Carrito.count();
    document.querySelectorAll('.cart-badge, #topnav-cart-badge').forEach(el => {
      el.textContent    = count || '';
      el.style.display  = count > 0 ? 'flex' : 'none';
    });
  }

  if (!document.getElementById('ui-keyframes')) {
    const s = document.createElement('style');
    s.id = 'ui-keyframes';
    s.textContent = `
      @keyframes toastIn  { from { transform:translateX(110%); opacity:0; } to { transform:translateX(0); opacity:1; } }
      @keyframes toastOut { from { transform:translateX(0); opacity:1; } to { transform:translateX(110%); opacity:0; } }
      @keyframes fadeIn   { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
      @keyframes spin     { to { transform:rotate(360deg); } }
      .modal-overlay.active .modal-box { animation: fadeIn .18s ease; }
    `;
    document.head.appendChild(s);
  }

  return { toast, modal, fmt, statusBadge, catIcon, updateCartBadge };
})();
